from .cmbscat_class import cmbscat_pipe

__all__ = ["cmbscat_pipe"]
